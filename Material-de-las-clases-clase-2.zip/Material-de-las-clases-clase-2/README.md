# Conecta Cultura

Proyecto incremental de la asignatura Desarrollo FullStack II.

## Integrante
- Nombre: [Tu Nombre Aquí]
- Sección: [Tu Sección]

## Descripción
Plataforma para descubrir talleres, actividades y eventos comunitarios.

## Estructura del Proyecto
- Páginas HTML5 semánticas y multipágina (Inicio, Nosotros, Noticias, Detalles, Agenda, Participar, Confirmación, Recursos).
- Hoja de estilos externa con variables CSS, Flexbox, CSS Grid y diseño adaptable.
- Archivo JavaScript externo.

## Fuentes de Imágenes y Recursos
- `fotografia.jpg`: Fotografía urbana - Fuente con licencia libre.
- `huerto.jpg`: Huerta comunitaria - Fuente con licencia libre.
- `programacion.jpg`: Taller tecnológico - Fuente con licencia libre.

## Ejecución
Abrir `index.html` en el navegador o utilizar la extensión Live Server de VS Code.